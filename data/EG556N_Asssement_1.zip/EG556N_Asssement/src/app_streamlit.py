import json
import numpy as np
import pandas as pd
import joblib
import streamlit as st
from pathlib import Path
import tensorflow as tf
from tensorflow import keras

# -----------------------------
# CONFIG PATHS (edit if needed)
# -----------------------------
from pathlib import Path

# Folder containing this script: .../EG556N_Asssement/src
BASE_DIR = Path(__file__).resolve().parent

# Project root: .../EG556N_Asssement
ROOT_DIR = BASE_DIR.parent

MODEL_DIR = ROOT_DIR / "outputs" / "model_artifacts"
DATA_DIR  = ROOT_DIR / "data"

MODEL_PATH  = MODEL_DIR / "eor_nn_alpha03.keras"
SCALER_PATH = MODEL_DIR / "scaler_alpha03.joblib"
LE_PATH     = MODEL_DIR / "label_encoder.joblib"
CFG_PATH    = MODEL_DIR / "config_alpha03.json"

RANGES_PATH = DATA_DIR / "NeuroFuzzy_EOR_Extracted_Tables.xlsx"
RANGES_SHEET = "Table1_Ranges"


# Debug prints (remove later if you want)
print("MODEL_PATH:", MODEL_PATH, "| exists:", MODEL_PATH.exists())
print("SCALER_PATH:", SCALER_PATH, "| exists:", SCALER_PATH.exists())
print("LE_PATH:", LE_PATH, "| exists:", LE_PATH.exists())
print("CFG_PATH:", CFG_PATH, "| exists:", CFG_PATH.exists())
print("RANGES_PATH:", RANGES_PATH, "| exists:", RANGES_PATH.exists())

# -----------------------------
# Load artifacts
# -----------------------------
@st.cache_resource
def load_artifacts():
    model = keras.models.load_model(MODEL_PATH)
    scaler = joblib.load(SCALER_PATH)
    le = joblib.load(LE_PATH)
    with open(CFG_PATH, "r") as f:
        cfg = json.load(f)
    return model, scaler, le, cfg

# -----------------------------
# Build fuzzy envelopes from Table1_Ranges
# -----------------------------
def norm_tech(x):
    if pd.isna(x):
        return np.nan
    x = str(x).strip().replace("CO22", "CO2").replace("*", "")
    return x

def norm_form(x):
    if pd.isna(x):
        return np.nan
    x = str(x).strip().lower()
    if "sandstone" in x:
        return "Sandstone"
    if "unconsolidated" in x:
        return "Unconsolidated sands"
    if "carbonate" in x:
        return "Carbonates"
    return np.nan

@st.cache_data
def load_env():
    table1 = pd.read_excel(RANGES_PATH, sheet_name=RANGES_SHEET, engine="openpyxl")

    table1["technique"] = table1["EOR technique"].apply(norm_tech)
    table1["formation_category"] = table1["Formation type"].apply(norm_form)
    table1 = table1.dropna(subset=["technique", "formation_category"]).copy()

    ENV = {}
    for _, r in table1.iterrows():
        key = (r["technique"], r["formation_category"])
        ENV[key] = {
            "depth": (r["Depth min (ft)"], r["Depth max (ft)"]),
            "por":   (r["Porosity min (%)"], r["Porosity max (%)"]),
            "perm":  (r["Permeability min (mD)"], r["Permeability max (mD)"]),
            "api":   (r["Oil gravity min (°API)"], r["Oil gravity max (°API)"]),
            "visc":  (r["Oil viscosity min (cp)"], r["Oil viscosity max (cp)"]),
            "so":    (r["So at start min (%)"], r["So at start max (%)"])
        }
    TECHS_ALL = sorted(set(k[0] for k in ENV.keys()))
    return ENV, TECHS_ALL

def trap_membership(x, L, U, alpha=0.3):
    if pd.isna(x) or pd.isna(L) or pd.isna(U):
        return 0.0
    if U == L:
        return 1.0 if x == L else 0.0

    w = U - L
    a = L - alpha * w
    d = U + alpha * w

    if x <= a or x >= d:
        return 0.0
    elif L <= x <= U:
        return 1.0
    elif a < x < L:
        return (x - a) / (L - a)
    else:
        return (d - x) / (d - U)

def fuzzy_score_one(ENV, tech, form, x, alpha=0.3):
    key = (tech, form)
    if key not in ENV:
        return 0.0

    e = ENV[key]
    m_depth = trap_membership(x["depth_ft"], *e["depth"], alpha=alpha)
    m_por   = trap_membership(x["porosity_pct"], *e["por"], alpha=alpha)
    m_perm  = trap_membership(x["perm_md"], *e["perm"], alpha=alpha)
    m_api   = trap_membership(x["api"], *e["api"], alpha=alpha)
    m_visc  = trap_membership(x["visc_cp"], *e["visc"], alpha=alpha)
    m_so    = trap_membership(x["so_pct"], *e["so"], alpha=alpha)

    # soft AND (mean) is more robust than min
    return float(np.mean([m_depth, m_por, m_perm, m_api, m_visc, m_so]))

def compute_fuzzy_scores(ENV, TECHS_ALL, form, x, alpha=0.3):
    scores = {}
    for tech in TECHS_ALL:
        scores[tech] = fuzzy_score_one(ENV, tech, form, x, alpha=alpha)
    return scores

def fuzzy_explain_one(ENV, tech, form, x, alpha=0.3):
    key = (tech, form)
    if key not in ENV:
        return None

    e = ENV[key]
    parts = {
        "Depth (ft)":      (x["depth_ft"], *e["depth"]),
        "Porosity (%)":    (x["porosity_pct"], *e["por"]),
        "Permeability (mD)": (x["perm_md"], *e["perm"]),
        "API (°API)":      (x["api"], *e["api"]),
        "Viscosity (cp)":  (x["visc_cp"], *e["visc"]),
        "So (%)":          (x["so_pct"], *e["so"]),
    }

    rows = []
    memberships = []
    for var, (val, L, U) in parts.items():
        m = trap_membership(val, L, U, alpha=alpha)
        memberships.append(m)
        rows.append({
            "Variable": var,
            "Input": val,
            "Range_Min": L,
            "Range_Max": U,
            "Membership": float(m)
        })

    return rows, float(np.mean(memberships))

# -----------------------------
# Feature assembly for NN
# IMPORTANT: must match NB03 feature pipeline
# -----------------------------
def build_features_for_nn(x, form, TECHS_ALL, fuzzy_scores):
    # mid = single input; span = unknown at inference -> set 0
    depth_mid = x["depth_ft"]
    por_mid = x["porosity_pct"]
    perm_mid = x["perm_md"]
    api_mid = x["api"]
    visc_mid = x["visc_cp"]
    so_mid = x["so_pct"]

    # spans as 0 (unknown for single-point input)
    depth_span = 0.0
    por_span = 0.0
    perm_span = 0.0
    api_span = 0.0
    visc_span = 0.0
    so_span = 0.0

    EPS = 1e-6
    log_perm_mid = np.log10(max(perm_mid, 0.0) + EPS)
    log_visc_mid = np.log10(max(visc_mid, 0.0) + EPS)
    log_perm_span = np.log10(perm_span + 1.0 + EPS)
    log_visc_span = np.log10(visc_span + 1.0 + EPS)

    # numeric feature vector (must match meta["numeric_features"])
    numeric = np.array([
        depth_mid, por_mid, perm_mid, api_mid, visc_mid, so_mid,
        depth_span, por_span, perm_span, api_span, visc_span, so_span,
        log_perm_mid, log_visc_mid, log_perm_span, log_visc_span
    ], dtype=float)

    # formation one-hot (must match meta formation one-hot ordering from training)
    # We'll use a stable ordering:
    form_names = ["Sandstone", "Carbonates", "Unconsolidated sands"]
    form_onehot = np.array([1.0 if form == f else 0.0 for f in form_names], dtype=float)

    # fuzzy features: align to TECHS_ALL ordering
    fuzzy_vec = np.array([fuzzy_scores.get(t, 0.0) for t in TECHS_ALL], dtype=float)

    # final concatenated feature vector
    return np.concatenate([numeric, form_onehot, fuzzy_vec], axis=0)

# -----------------------------
# Rare class override (optional)
# -----------------------------
def predict_case(model, scaler, le, ENV, TECHS_ALL, x, formation_category, alpha=0.3,
                 rare_override=True, rare_threshold=0.90, nn_conf_threshold=0.60):
    fuzzy_scores = compute_fuzzy_scores(ENV, TECHS_ALL, formation_category, x, alpha=alpha)

    # NN prediction on trainable labels
    feats = build_features_for_nn(x, formation_category, TECHS_ALL, fuzzy_scores)
    feats_s = scaler.transform([feats])
    probs = model.predict(feats_s, verbose=0)[0]

    nn_idx = int(np.argmax(probs))
    nn_label = le.inverse_transform([nn_idx])[0]
    nn_conf = float(np.max(probs))

    # Top-3 within trainable model classes
    top3_idx = np.argsort(probs)[-3:][::-1]
    top3 = [(le.inverse_transform([i])[0], float(probs[i])) for i in top3_idx]

    # Rare override logic
    mode = "NN"
    final_label = nn_label
    final_score = nn_conf

    if rare_override:
        rare_candidates = ["Hot water", "Miscible acid gas"]
        best_rare = None
        best_rare_score = -1
        for rc in rare_candidates:
            s = fuzzy_scores.get(rc, 0.0)
            if s > best_rare_score:
                best_rare_score = s
                best_rare = rc

        if best_rare is not None and best_rare_score >= rare_threshold and nn_conf < nn_conf_threshold:
            final_label = best_rare
            final_score = best_rare_score
            mode = "FUZZY_RARE_OVERRIDE"

    return {
        "final_label": final_label,
        "final_score": final_score,
        "mode": mode,
        "nn_label": nn_label,
        "nn_conf": nn_conf,
        "top3": top3,
        "fuzzy_scores": fuzzy_scores
    }

# -----------------------------
# Streamlit UI
# -----------------------------

import streamlit as st

st.set_page_config(page_title="EOR Technique Screening (Neuro-Fuzzy + Neural Network)", layout="wide")
st.title("EOR Technique Screening Tool (Neuro-Fuzzy + Neural Network)")

st.caption("Inputs: Depth, Porosity, Permeability, API, Viscosity, So. "
           "Fuzzy envelopes from Table1_Ranges + Neural Network calibration. (alpha=0.30)")

model, scaler, le, cfg = load_artifacts()
ENV, TECHS_ALL = load_env()
alpha = cfg.get("alpha", 0.30)

# Sidebar inputs
st.sidebar.header("Input Reservoir/Fluid Properties")

formation_category = st.sidebar.selectbox(
    "Formation category",
    ["Sandstone", "Carbonates", "Unconsolidated sands"],
    index=0
)

depth_ft = st.sidebar.number_input("Depth (ft)", min_value=0.0, value=5000.0, step=50.0)
porosity_pct = st.sidebar.number_input("Porosity (%)", min_value=0.0, max_value=100.0, value=20.0, step=0.5)
perm_md = st.sidebar.number_input("Permeability (mD)", min_value=0.0, value=100.0, step=10.0)
api = st.sidebar.number_input("Oil Gravity (°API)", min_value=0.0, max_value=80.0, value=35.0, step=0.5)
visc_cp = st.sidebar.number_input("Viscosity (cp)", min_value=0.0, value=2.0, step=0.1)
so_pct = st.sidebar.number_input("Oil Saturation at start (%)", min_value=0.0, max_value=100.0, value=55.0, step=1.0)

rare_override = st.sidebar.checkbox("Enable rare-class fuzzy override (Hot water, Acid gas)", value=True)
rare_threshold = st.sidebar.slider("Rare override threshold (fuzzy)", 0.50, 1.00, 0.90, 0.01)
nn_conf_threshold = st.sidebar.slider("Neural Network confidence threshold", 0.10, 0.95, 0.60, 0.05)

if st.sidebar.button("Run Screening"):
    
    x = {
        "depth_ft": depth_ft,
        "porosity_pct": porosity_pct,
        "perm_md": perm_md,
        "api": api,
        "visc_cp": visc_cp,
        "so_pct": so_pct
    }

    result = predict_case(
        model=model, scaler=scaler, le=le,
        ENV=ENV, TECHS_ALL=TECHS_ALL,
        x=x, formation_category=formation_category,
        alpha=alpha,
        rare_override=rare_override,
        rare_threshold=rare_threshold,
        nn_conf_threshold=nn_conf_threshold
    )

    if result["mode"] == "FUZZY_RARE_OVERRIDE":
        st.warning(
            f"Rare-technique override triggered: `{result['final_label']}` "
            f"(fuzzy={result['final_score']:.3f}) because NN confidence was low "
            f"({result['nn_conf']:.3f})."
        )

    col1, col2 = st.columns([1, 1])

    st.subheader("Explainability (Fuzzy Membership vs Table‑1 Envelopes)")

    # Explain final recommendation
    exp = fuzzy_explain_one(ENV, result["final_label"], formation_category, x, alpha=alpha)
    if exp is None:
        st.info("No Table‑1 envelope found for this technique × formation.")
    else:
        exp_rows, exp_score = exp
        exp_df = pd.DataFrame(exp_rows)
        st.write(f"Fuzzy mean score for `{result['final_label']}` = **{exp_score:.3f}**")
        st.dataframe(exp_df, use_container_width=True)
        st.bar_chart(exp_df.set_index("Variable")["Membership"])

    with col1:
        st.subheader("Recommendation")
        st.write(f"**Final Technique:** `{result['final_label']}`")
        st.write(f"**Mode:** {result['mode']}")
        st.write(f"**Score/Confidence:** {result['final_score']:.3f}")

        st.subheader("Top-3 (NN)")
        for t, p in result["top3"]:
            st.write(f"- `{t}`: **{p:.3f}**")

    with col2:
        st.subheader("Fuzzy Suitability Scores")
        fs = pd.Series(result["fuzzy_scores"]).sort_values(ascending=False)
        st.bar_chart(fs)

    st.subheader("Detailed Inputs")
    st.json({"formation_category": formation_category, **x})
    
    st.subheader("Top‑3 Recommendations (NN)")
    top3_df = pd.DataFrame(result["top3"], columns=["Technique", "Probability"])
    st.dataframe(top3_df, use_container_width=True)

    st.bar_chart(top3_df.set_index("Technique")["Probability"])

import json

export_payload = {
    "inputs": {"formation_category": formation_category, **x},
    "final": {
        "technique": result["final_label"],
        "score": float(result["final_score"]),
        "mode": result["mode"]
    },
    "nn": {
        "technique": result["nn_label"],
        "confidence": float(result["nn_conf"]),
        "top3": [{"technique": t, "prob": float(p)} for t, p in result["top3"]]
    },
    "fuzzy_scores": {k: float(v) for k, v in result["fuzzy_scores"].items()}
}

# JSON download
st.download_button(
    label="⬇️ Download Result (JSON)",
    data=json.dumps(export_payload, indent=2),
    file_name="eor_screening_result.json",
    mime="application/json"
)

# CSV download (Top-3)
csv_data = top3_df.to_csv(index=False)
st.download_button(
    label="⬇️ Download Top‑3 (CSV)",
    data=csv_data,
    file_name="eor_top3.csv",
    mime="text/csv"
)
